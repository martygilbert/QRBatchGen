#!/bin/csh -f

set path=(/System/Library/Frameworks/JavaVM.framework/Versions/1.5.0/Home $path)

